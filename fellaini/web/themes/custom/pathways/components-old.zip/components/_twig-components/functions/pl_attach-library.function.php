<?php
/**
 * @file
 * Add "attach_library" function for Pattern Lab.
 */

$function = new Twig_SimpleFunction('attach_library', function ($string) {
  return '';
});
