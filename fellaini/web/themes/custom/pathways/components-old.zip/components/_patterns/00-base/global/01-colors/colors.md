---
title: Colors
---
Colors below are automatically pulled from `_color-vars.scss` and can be used like so:

```scss
.class {
  color: $gray;
}
```
