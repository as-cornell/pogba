---
el: ".button"
title: "Button Styling"
---
## Button Styling

Default button styling with alternative variations - use mixins in `_buttons.scss`.
