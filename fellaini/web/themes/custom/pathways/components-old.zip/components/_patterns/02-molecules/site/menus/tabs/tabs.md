---
el: ".tabs"
title: "Tabs"
---
## Tabs

This controls styles for default Drupal tabs as well as just javascript tabs on the page (example below is javascript tabs). See the section in `tabs.twig` commented as `{# PL Specific (javascript version) #}` for the example markup for js tabs.
