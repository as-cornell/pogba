---
title: Figure
---
### How to use the figure element

The figure element includes the image element as well as an image caption.
