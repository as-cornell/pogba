---
el: ".grid"
title: "Grid"
---
## Grid Layout

Flex Grid uses flexbox with the last item(s) stretched to fill by default. Grid includes classes and mixins for usage (mixins recommended - see `components/_patterns/03-organisms/card-grid/_card-grid.scss` for an example). Background color and height added for display in Pattern Lab only.
