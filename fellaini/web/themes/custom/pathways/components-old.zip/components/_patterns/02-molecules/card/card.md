---
el: ".card"
title: "Card default variation"
---
## Card
_Title and subtext_

A card
