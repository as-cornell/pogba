---
el: ".card-bg"
title: "Card with background"
---
## Card
_Title and subtext_

A card variation with a background color.
